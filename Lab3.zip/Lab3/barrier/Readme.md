# Barrier Synchronization (Go)

This program shows how to use **mutexes** and **semaphores** in Go to create a simple **barrier** — a point where all goroutines must stop and wait for each other before continuing.

### How it works
- Each goroutine does **Part A**.
- When it finishes, it increments a shared counter (`count`).
- The **last** goroutine to arrive releases the semaphore.
- Once released, all goroutines continue to **Part B** together.
