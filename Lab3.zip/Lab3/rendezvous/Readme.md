# Rendezvous Synchronization (Go)

This program demonstrates a simple **rendezvous** synchronization pattern in Go.  
A rendezvous ensures that all goroutines complete one part of their work (**Part A**) before any move on to the next (**Part B**).

---

## How It Works

1. Each goroutine runs `WorkWithRendezvous()` and performs **Part A**.
2. When a goroutine finishes Part A, it increments a shared counter (`count`).
3. The last goroutine to arrive **closes the `barrier` channel**, which releases all waiting goroutines.
4. All goroutines then proceed to **Part B** together.

This prevents any goroutine from continuing early — they all “meet” at the rendezvous point first.
