package main

import (
	"fmt"
	"math/rand/v2"
	"sync"
	"sync/atomic"
	"time"
)

func WorkWithRendezvous(wg *sync.WaitGroup, barrier chan bool, threadCount int, Num int, count *int32) bool {
	var X time.Duration
	X = time.Duration(rand.IntN(5))
	time.Sleep(X * time.Second) //wait random time amount

	fmt.Println("Part A", Num)

	// Increment the count of arrived goroutines
	newCount := atomic.AddInt32(count, 1)

	// If this is the last goroutine to arrive, close the barrier channel to release all waiting goroutines
	if int(newCount) == threadCount {
		close(barrier)
	}

	// Wait for the barrier to be released
	<-barrier

	fmt.Println("PartB", Num)
	wg.Done()
	return true
}

func main() {
	var wg sync.WaitGroup
	threadCount := 5
	var count int32 = 0

	barrier := make(chan bool)

	wg.Add(threadCount)

	// launch the goroutines
	for N := range threadCount {
		go WorkWithRendezvous(&wg, barrier, threadCount, N, &count)
	}
	wg.Wait() //wait here until everyone (10 go routines) is done

}
