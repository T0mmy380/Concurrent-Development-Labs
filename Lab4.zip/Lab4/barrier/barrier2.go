//Barrier.go Template Code
//Copyright (C) 2024 Dr. Joseph Kehoe

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.

//--------------------------------------------
// Author: Joseph Kehoe (Joseph.Kehoe@setu.ie)
// Created on 30/9/2024
// Modified by:
// Description:
// A simple barrier implemented using mutex and unbuffered channel
// Issues:
// None I hope
//1. Change mutex to atomic variable
//2. Make it a reusable barrier
//--------------------------------------------

package main

import (
	"fmt"
	"sync"
	"time"
)

// Barrier is a reusable barrier for N goroutines.
type Barrier struct {
	n          int
	count      int
	generation int
	mutex      sync.Mutex
	cond       *sync.Cond
}

func NewBarrier(n int) *Barrier {
	b := &Barrier{n: n}
	b.cond = sync.NewCond(&b.mutex)
	return b
}

// Wait blocks until n goroutines have called Wait. It's reusable across cycles.
func (b *Barrier) Wait() {
	b.mutex.Lock()
	gen := b.generation
	b.count++
	if b.count == b.n {
		// last to arrive: advance generation, reset count, wake all
		b.generation++
		b.count = 0
		b.cond.Broadcast()
		b.mutex.Unlock()
		return
	}
	// wait for generation to change
	for gen == b.generation {
		b.cond.Wait()
	}
	b.mutex.Unlock()
}

func doStuff(goNum int, b *Barrier, wg *sync.WaitGroup) {
	defer wg.Done()
	time.Sleep(time.Second)
	fmt.Println("Part A", goNum)

	b.Wait() // reusable barrier

	fmt.Println("Part B", goNum)
}

func main() {
	totalRoutines := 10
	runs := 5

	for r := 0; r < runs; r++ {
		fmt.Println("=== Run", r+1, "===")
		var wg sync.WaitGroup
		barrier := NewBarrier(totalRoutines)

		for i := 0; i < totalRoutines; i++ {
			wg.Add(1)
			go doStuff(i, barrier, &wg)
		}

		wg.Wait() // wait for all goroutines in this run
	}
}
