# Barrier Synchronization (Go)

- The program demonstrates a reusable barrier that synchronizes `N` goroutines.
- The barrier uses an atomic counter (`atomic.AddInt32`) and one channel per "generation" (stored using `atomic.Value`).
- When the last goroutine arrives at the barrier, it closes the current generation channel to release all waiters and swaps in a fresh channel for the next use.

---

## How It Works

- Each goroutine calls `Barrier.Wait()` after completing "Part A".
- `Wait()` atomically increments a counter; the goroutine that reaches the count `N` resets the counter, creates a new channel for the next generation, and closes the old channel to wake everyone.
- Other goroutines block reading from the generation channel until it is closed.
