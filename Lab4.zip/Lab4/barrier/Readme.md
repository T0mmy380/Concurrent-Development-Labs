# Barrier Synchronization (Go)

This program demonstrates a **barrier synchronization** mechanism implemented in Go using an **atomic counter** and an **unbuffered channel**.

A **barrier** ensures that all goroutines complete one part of their work (**Part A**) before any move on to the next (**Part B**).  
This version also resets the barrier automatically, making it reusable.

---

## How It Works

1. Each goroutine performs **Part A**.
2. When done, it atomically increments a shared counter (`arrived`).
3. The **last** goroutine to arrive sends signals through a channel to unblock the others.
4. All goroutines then proceed to **Part B** together.
5. Each goroutine decrements the counter again, allowing the barrier to be reused.
