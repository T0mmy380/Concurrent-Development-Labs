# Dining Philosophers (Go)

A small Go program that simulates the classic **Dining Philosophers** concurrency problem using buffered channels as binary semaphores for forks.

This implementation includes:
- Clear, line-by-line comments.
- A simple **deadlock-avoidance** strategy (asymmetric fork picking).
- Configurable number of philosophers and rounds.
- A full open-source license (MIT).

---

## Why this can deadlock (and how we avoid it)

If every philosopher picks up their **left** fork and then their **right** fork, they can all hold one fork and wait forever for the other — a classic **circular wait** deadlock.

To break the cycle, we make **one philosopher** (index `0`) pick up **right then left**, while the others pick **left then right**. This removes circular wait and prevents deadlock.

---

## How it works

- Each fork is a **buffered channel of capacity 1**, acting like a **binary semaphore**:
  - `fork <- true`  acquires the fork (succeeds if buffer has space).
  - `<-fork`        releases the fork (consumes a token).
- Thinking/eating times are randomized to surface concurrency interleavings.