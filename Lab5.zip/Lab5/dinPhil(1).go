// Dining Philosophers Template Code
// Author: Joseph Kehoe
// Created: 21/10/24
//GPL Licence
// MISSING:
// 1. Readme
// 2. Full licence info.
// 3. Comments
// 4. It can Deadlock!

package main

import (
	"fmt"
	"math/rand/v2"
	"sync"
	"time"
)

// think makes the philosopher think for a random time
func think(index int) {
	var X time.Duration
	X = time.Duration(rand.IntN(5))
	time.Sleep(X * time.Second) //wait random time amount
	fmt.Println("Phil: ", index, "was thinking")
}

// eat makes the philosopher eat for a random time
func eat(index int) {
	var X time.Duration
	X = time.Duration(rand.IntN(5))
	time.Sleep(X * time.Second) //wait random time amount
	fmt.Println("Phil: ", index, "was eating")
}

// getForks aquires the two forks using channels
func getForks(index int, forks map[int]chan bool) {
	// if index is 0, pick up right fork first (prevents circular wait - deadlock)
	if index == 0 {
		forks[(index+1)%5] <- true // pick up right fork first
		forks[index] <- true       // pick up left fork second
	} else {
		forks[index] <- true       // pick up left fork first
		forks[(index+1)%5] <- true // pick up right fork second
	}

}

// putForks releases the two forks
func putForks(index int, forks map[int]chan bool) {
	<-forks[index]       // put down left fork
	<-forks[(index+1)%5] // put down right fork
}

// doPhilStuff is the main function for each philosopher
func doPhilStuff(index int, wg *sync.WaitGroup, forks map[int]chan bool) {
	for {
		think(index)           // philosopher is thinking
		getForks(index, forks) // philosopher is hungry and tries to get forks
		eat(index)             // philosopher is eating
		putForks(index, forks) // philosopher puts down forks
	}
}

func main() {
	var wg sync.WaitGroup
	philCount := 5
	wg.Add(philCount)
	forks := make(map[int]chan bool) // make empty map

	for k := range philCount {
		forks[k] = make(chan bool, 1) // fill map with channels bool (buffered size 1)
	} //set up forks
	for N := range philCount {
		go doPhilStuff(N, &wg, forks) //process each philosopher
	} //start philosophers
	wg.Wait() //wait here until everyone (10 go routines) is done

} //main
