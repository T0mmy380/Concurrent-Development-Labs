package main

import (
	"fmt"
	"sync"
)

// Event represents a unit of work produced and consumed.
type Event struct {
	ID int
}

func (e *Event) Consume() {
	fmt.Printf("Consumed event %d\n", e.ID)
}

func main() {
	const (
		numThreads    = 100 // number of producer goroutines and consumer goroutines
		bufferSize    = 20  // capacity of the buffer
		eventsPerProd = 10  // events each producer creates
	)

	buffer := make(chan *Event, bufferSize)

	var prodWg sync.WaitGroup
	var consWg sync.WaitGroup

	// Start consumers
	consWg.Add(numThreads)
	for i := 0; i < numThreads; i++ {
		go func(consumerID int) {
			defer consWg.Done()
			for e := range buffer {
				_ = consumerID
				e.Consume()
			}
		}(i)
	}

	// Start producers
	prodWg.Add(numThreads)
	for p := 0; p < numThreads; p++ {
		go func(prodID int) {
			defer prodWg.Done()
			for j := 0; j < eventsPerProd; j++ {
				eventID := prodID*eventsPerProd + j
				buffer <- &Event{ID: eventID}
			}
		}(p)
	}

	// Wait for all producers to finish, then close the buffer so consumers exit.
	prodWg.Wait()
	close(buffer)

	// Wait for consumers to finish processing remaining events.
	consWg.Wait()

	fmt.Println("All events produced and consumed.")
}
